package coreservlets;

import javax.faces.bean.*;

@ManagedBean(name="currentLookupService", eager=true)
@ApplicationScoped
public class CustomerSimpleMap2 
       extends CustomerSimpleMap {
}
