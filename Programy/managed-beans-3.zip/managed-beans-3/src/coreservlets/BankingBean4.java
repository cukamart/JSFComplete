package coreservlets;

import javax.faces.bean.*;

@ManagedBean 
public class BankingBean4 extends BankingBean { 
  @ManagedProperty(value="#{currentLookupService}")
  private CustomerLookupService service;
  
  public void setService(CustomerLookupService service) {
    this.service = service;
  }

  @Override
  public String showBalance() {
    if (!password.equals("secret")) {
      return("wrong-password4");
    }
    customer = service.findCustomer(customerId);
    if (customer == null) {
      return("unknown-customer4");
    } else if (customer.getBalance() < 0) {
      return("negative-balance4");
    } else if (customer.getBalance() < 10000) {
      return("normal-balance4");
    } else {
      return("high-balance4");
    }
  }
}
