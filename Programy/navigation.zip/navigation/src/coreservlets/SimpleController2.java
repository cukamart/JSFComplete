package coreservlets;

public class SimpleController2 
       extends SimpleController {

  // Inherits getMessage, setMessage, 
  // and doNavigation. doNavigation returns 
  // "too-short", "page1", "page2", or "page3".
  
}
